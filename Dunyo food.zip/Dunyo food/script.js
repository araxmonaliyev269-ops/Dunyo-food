const buttons = document.querySelectorAll(".add-cart");
const count = document.getElementById("cart-count");

let cart = 0;

buttons.forEach(button => {
    button.addEventListener("click", () => {
        cart++;
        count.textContent = cart;
        alert("Mahsulot savatga qo'shildi!");
    });
});

const search = document.getElementById("search");

search.addEventListener("keyup", () => {
    const value = search.value.toLowerCase();
    const cards = document.querySelectorAll(".food-card");

    cards.forEach(card => {
        const name = card.querySelector("h3").textContent.toLowerCase();

        if (name.includes(value)) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
});